#include "Energia.h"
#include "Wire.h"
#include "I2Cdev.h"
#include "MPU6050.h"


void setup();
void loop();


// class default I2C address is 0x68
// specific I2C addresses may be passed as a parameter here
// AD0 low = 0x68 (default for InvenSense evaluation board)
// AD0 high = 0x69
MPU6050 accelgyro;

int16_t ax, ay, az;
int16_t gx, gy, gz;

#define SDA_PIN 	38
#define SCL_PIN 	19

bool blinkState = false;

void setup() {
    // join I2C bus (I2Cdev library doesn't do this automatically)
    Wire.begin();

    // initialize serial communication
    // (38400 chosen because it works as well at 8MHz as it does at 16MHz, but
    // it's really up to you depending on your project)
    Serial.begin(38400);

    // initialize device
    Serial.println("Initializing I2C devices...");
    accelgyro.initialize();

    // verify connection
    Serial.println("Testing device connections...");
    Serial.println(accelgyro.testConnection() ? "MPU6050 connection successful" : "MPU6050 connection failed");

    // configure Arduino LED for
//    pinMode(SDA_PIN, OUTPUT);
//    pinMode(SCL_PIN, OUTPUT);
}

void loop()
{
    // read raw accel/gyro measurements from device
    accelgyro.getMotion6(&ax, &ay, &az, &gx, &gy, &gz);

    // these methods (and a few others) are also available
    accelgyro.getAcceleration(&ax, &ay, &az);
    accelgyro.getRotation(&gx, &gy, &gz);

    // Display tab-separated accel/gyro x/y/z values
    Serial.print("Accel:\t");
    Serial.print(ax); Serial.print(", \t");
    Serial.print(ay); Serial.print(", \t");
    Serial.println(az);

    Serial.print("Gyros:\t");
    Serial.print(gx); Serial.print(", \t");
    Serial.print(gy); Serial.print(", \t");
    Serial.println(gz);
    delay(150);

//    // blink LED to indicate activity
//    blinkState = !blinkState;
//    digitalWrite(SDA_PIN, blinkState);
//    digitalWrite(SCL_PIN, blinkState);
//    delay(500);
}
